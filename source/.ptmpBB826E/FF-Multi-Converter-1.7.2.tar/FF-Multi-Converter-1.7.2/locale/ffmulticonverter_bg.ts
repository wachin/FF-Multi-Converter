<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS><TS version="2.0" language="bg" sourcelanguage="">
<context>
    <name>AboutDialog</name>
    <message>
        <location filename="../ffmulticonverter/about_dlg.py" line="39"/>
        <source>&amp;Close</source>
        <translation>&amp;Затвори</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/about_dlg.py" line="52"/>
        <source>About FF Multi Converter</source>
        <translation>Относно FF Multi Converter</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/about_dlg.py" line="38"/>
        <source>C&amp;redits</source>
        <translation>Заслуги</translation>
    </message>
</context>
<context>
    <name>AddorEditPreset</name>
    <message>
        <location filename="../ffmulticonverter/presets_dlgs.py" line="393"/>
        <source>Preset name (one word, A-z, 0-9)</source>
        <translation>Име на пресет (една дума, А-я, 0-9)</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/presets_dlgs.py" line="395"/>
        <source>Preset label</source>
        <translation>Найменование на Пресет</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/presets_dlgs.py" line="397"/>
        <source>Preset command line parameters</source>
        <translation>Командни параметри на пресет.</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/presets_dlgs.py" line="399"/>
        <source>Output file extension</source>
        <translation>Екстенжън на конвертираният файл.</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/presets_dlgs.py" line="403"/>
        <source>Edit %1</source>
        <translation type="obsolete">Редактирай %1</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/presets_dlgs.py" line="425"/>
        <source>Add preset</source>
        <translation>Добави пресет</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/presets_dlgs.py" line="486"/>
        <source>Error!</source>
        <translation>Грешка!</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/presets_dlgs.py" line="446"/>
        <source>Preset name can&apos;t be left blank.</source>
        <translation>Името на пресет не може да бъде оставено празно.</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/presets_dlgs.py" line="434"/>
        <source>Preset name must be one word and contain only letters and digits.</source>
        <translation type="obsolete">Името на пресет трябва да бъде една дума и да съдържа само букви и цифри.</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/presets_dlgs.py" line="465"/>
        <source>Preset label can&apos;t be left blank.</source>
        <translation>Найменованието на пресет не може да бъде оставено празно. </translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/presets_dlgs.py" line="472"/>
        <source>Command label can&apos;t be left blank.</source>
        <translation>Командното описание не може да бъде оставено празно. </translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/presets_dlgs.py" line="479"/>
        <source>Extension label can&apos;t be left blank.</source>
        <translation>Описанието на екстенжъна не може да бъде оставено празно. </translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/presets_dlgs.py" line="453"/>
        <source>Extension must be one word and must not start with a dot.</source>
        <translation type="obsolete">Екстенжъна трябва да бъде една дума и да не започва с точка. </translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/presets_dlgs.py" line="423"/>
        <source>Edit {0}</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/presets_dlgs.py" line="486"/>
        <source>Extension must be one word and must not start with a  dot.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/presets_dlgs.py" line="454"/>
        <source>Preset name must be one word, start with a letter and contain only letters, digits, underscores, hyphens, colons and periods. It cannot also start with xml.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>AudioVideoTab</name>
    <message>
        <location filename="../ffmulticonverter/ffmulticonverter.py" line="598"/>
        <source>No Change</source>
        <translation type="obsolete">Без промяна</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/audiovideotab.py" line="60"/>
        <source>Convert to:</source>
        <translation>Конвертирай като:</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/ffmulticonverter.py" line="607"/>
        <source>Other</source>
        <translation type="obsolete">Други</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/audiovideotab.py" line="74"/>
        <source>Command:</source>
        <translation>Команда</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/audiovideotab.py" line="76"/>
        <source>Preset</source>
        <translation>Пресет</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/audiovideotab.py" line="37"/>
        <source>Default</source>
        <translation>По подразбиране</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/audiovideotab.py" line="82"/>
        <source>Video Size:</source>
        <translation>Размер на видеото</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/audiovideotab.py" line="83"/>
        <source>Aspect:</source>
        <translation>Зависимост</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/audiovideotab.py" line="84"/>
        <source>Frame Rate (fps):</source>
        <translation>Размер на Фреймовете в секунда(fps):</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/audiovideotab.py" line="85"/>
        <source>Video Bitrate (kbps):</source>
        <translation>Kaчество на видеото(kbps):</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/audiovideotab.py" line="123"/>
        <source>Frequency (Hz):</source>
        <translation>Честота (Херц):</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/ffmulticonverter.py" line="656"/>
        <source>Channels:</source>
        <translation type="obsolete">Канали:</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/audiovideotab.py" line="125"/>
        <source>Audio Bitrate (kbps):</source>
        <translation>Аудио Битреит (кб в сек):</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/audiovideotab.py" line="291"/>
        <source>Error!</source>
        <translation>Грешка!</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/audiovideotab.py" line="299"/>
        <source>Neither ffmpeg nor avconv are installed.
You will not be able to convert audio/video files until you install one of them.</source>
        <translation type="obsolete">Нито ffmpeg, нито avconv са инсталирани. 
Няма да можете да конвертирате аудио/видео файлове докато не инсталирате поне едно от тях.</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/ffmulticonverter.py" line="778"/>
        <source>Extension must be one word and must not start with a dot.</source>
        <translation type="obsolete">Екстенжън трябва да бъде една дума и да не започва с точка. </translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/ffmulticonverter.py" line="785"/>
        <source>The command LineEdit may not be empty.</source>
        <translation type="obsolete">Командата LineEdit не може да бъде празна. </translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/audiovideotab.py" line="108"/>
        <source>Preserve aspect ratio</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/audiovideotab.py" line="109"/>
        <source>Preserve video size</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/audiovideotab.py" line="124"/>
        <source>Audio Channels:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/audiovideotab.py" line="156"/>
        <source>Split file. Begin time</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/audiovideotab.py" line="158"/>
        <source>Duration</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/audiovideotab.py" line="164"/>
        <source>Embed subtitle:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/audiovideotab.py" line="169"/>
        <source>Rotate:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/audiovideotab.py" line="302"/>
        <source>Choose File</source>
        <translation type="unfinished">Избери файл</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/audiovideotab.py" line="44"/>
        <source>None</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/audiovideotab.py" line="46"/>
        <source>clockwise</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/audiovideotab.py" line="52"/>
        <source>vertical flip</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/audiovideotab.py" line="48"/>
        <source>counter clockwise</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/audiovideotab.py" line="51"/>
        <source>horizontal flip</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/audiovideotab.py" line="126"/>
        <source>Threads:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/audiovideotab.py" line="291"/>
        <source>Neither ffmpeg nor libav are installed.
You will not be able to convert audio/video files until you install one of them.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>CreditsDialog</name>
    <message>
        <location filename="../ffmulticonverter/about_dlg.py" line="70"/>
        <source>Written by</source>
        <translation>Написано от</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/about_dlg.py" line="71"/>
        <source>Translated by</source>
        <translation>Преведено от</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/about_dlg.py" line="72"/>
        <source>&amp;Close</source>
        <translation>&amp;Затвори</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/about_dlg.py" line="82"/>
        <source>Credits</source>
        <translation>Относно програмата</translation>
    </message>
</context>
<context>
    <name>DocumentTab</name>
    <message>
        <location filename="../ffmulticonverter/documenttab.py" line="41"/>
        <source>Convert:</source>
        <translation>Конвертирай:</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/documenttab.py" line="62"/>
        <source>Unocov is not installed.
You will not be able to convert document files until you install it.</source>
        <translation>Unocov не е инсталиран.⏎
Няма да можете да конвертирате документи докато не го инсталирате.</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/documenttab.py" line="75"/>
        <source>Error!</source>
        <translation>Грешка!</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/ffmulticonverter.py" line="1022"/>
        <source>%1 is not %2!</source>
        <translation type="obsolete">%1 не е %2!</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/documenttab.py" line="85"/>
        <source>You can not make parallel document conversions.</source>
        <translation type="obsolete">Не може да се извършват паралелни документни конвертирания.</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/ffmulticonverter.py" line="991"/>
        <source>%1 to %2</source>
        <translation type="obsolete">%1 до %2</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/documenttab.py" line="70"/>
        <source>{0} is not {1}!</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ImageTab</name>
    <message>
        <location filename="../ffmulticonverter/imagetab.py" line="37"/>
        <source>Convert to:</source>
        <translation>Конвертирай като:</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/imagetab.py" line="46"/>
        <source>Image Size:</source>
        <translation>Размер на изображението:</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/imagetab.py" line="107"/>
        <source>Error!</source>
        <translation>Грешка!</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/ffmulticonverter.py" line="953"/>
        <source>PythonMagick is not installed.
You will not be able to convert image files until you install it.</source>
        <translation type="obsolete">PythonMagick не е инсталиран.⏎
Няма да можете да конвертирате изображения докато не го инсталирате. </translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/imagetab.py" line="107"/>
        <source>The size LineEdit may not be empty.</source>
        <translation>Размерът на Редактиране на реда не може да бъде празен.</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/imagetab.py" line="57"/>
        <source>Maintain aspect ratio</source>
        <translation>Не променяй качеството на файлът</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/imagetab.py" line="40"/>
        <source>Extra options:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/imagetab.py" line="58"/>
        <source>Auto-crop</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/imagetab.py" line="62"/>
        <source>Rotate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/imagetab.py" line="62"/>
        <source>degrees - clockwise</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/imagetab.py" line="102"/>
        <source>ImageMagick is not installed.
You will not be able to convert image files until you install it.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/imagetab.py" line="66"/>
        <source>Vertical flip</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/imagetab.py" line="67"/>
        <source>Horizontal flip</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../ffmulticonverter/ffmulticonverter.py" line="74"/>
        <source>Output folder:</source>
        <translation>Папка за съхранение на конвертираният файл:</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/ffmulticonverter.py" line="86"/>
        <source>Audio/Video</source>
        <translation>Аудио/Видео</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/ffmulticonverter.py" line="86"/>
        <source>Images</source>
        <translation>Изображения</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/ffmulticonverter.py" line="87"/>
        <source>Documents</source>
        <translation>Документи</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/ffmulticonverter.py" line="96"/>
        <source>Delete original</source>
        <translation>Изтрий оригиналът</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/ffmulticonverter.py" line="97"/>
        <source>&amp;Convert</source>
        <translation>&amp;Конвертирай</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/ffmulticonverter.py" line="111"/>
        <source>Open</source>
        <translation>Отвори</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/ffmulticonverter.py" line="111"/>
        <source>Open a file</source>
        <translation>Отвори файл</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/ffmulticonverter.py" line="115"/>
        <source>Convert</source>
        <translation>Конвертирай</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/ffmulticonverter.py" line="115"/>
        <source>Convert files</source>
        <translation>Конвертирай файловете</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/ffmulticonverter.py" line="119"/>
        <source>Quit</source>
        <translation>Изход</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/ffmulticonverter.py" line="123"/>
        <source>Edit Presets</source>
        <translation>Редактирайте пресетите</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/ffmulticonverter.py" line="127"/>
        <source>Import</source>
        <translation>Импортиране</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/ffmulticonverter.py" line="127"/>
        <source>Import presets</source>
        <translation>Пресети за импортиране</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/ffmulticonverter.py" line="131"/>
        <source>Export</source>
        <translation>Експортиране</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/ffmulticonverter.py" line="131"/>
        <source>Export presets</source>
        <translation>Експортирай пресетите</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/ffmulticonverter.py" line="135"/>
        <source>Reset</source>
        <translation>Задай начални настройки</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/ffmulticonverter.py" line="135"/>
        <source>Reset presets</source>
        <translation>Пресети за задаване на начални настройки</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/ffmulticonverter.py" line="67"/>
        <source>Clear</source>
        <translation>Изчисти</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/ffmulticonverter.py" line="147"/>
        <source>Clear form</source>
        <translation>Изчисти формата</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/ffmulticonverter.py" line="151"/>
        <source>Preferences</source>
        <translation>Предпочитания</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/ffmulticonverter.py" line="175"/>
        <source>About</source>
        <translation>Относно</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/ffmulticonverter.py" line="180"/>
        <source>File</source>
        <translation>Файл</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/ffmulticonverter.py" line="181"/>
        <source>Edit</source>
        <translation>Редактирай</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/ffmulticonverter.py" line="182"/>
        <source>Presets</source>
        <translation>Пресети</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/ffmulticonverter.py" line="183"/>
        <source>Help</source>
        <translation>Помощ</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/ffmulticonverter.py" line="326"/>
        <source>All Files</source>
        <translation>Всички файлове</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/ffmulticonverter.py" line="326"/>
        <source>Audio/Video Files</source>
        <translation>Аудио/Видео Файлове</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/ffmulticonverter.py" line="327"/>
        <source>Image Files</source>
        <translation>Файлове с изображение</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/ffmulticonverter.py" line="327"/>
        <source>Document Files</source>
        <translation>Файлови Документи</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/ffmulticonverter.py" line="335"/>
        <source>Choose File</source>
        <translation>Избери файл</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/ffmulticonverter.py" line="386"/>
        <source>Choose output destination</source>
        <translation>Изберете папка, в която да запазите конвертираните файлове.</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/ffmulticonverter.py" line="424"/>
        <source>You must choose an output folder!</source>
        <translation>Трябва да изберете папка, в която да се запазят конвертираните данни.</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/ffmulticonverter.py" line="428"/>
        <source>Output folder does not exists!</source>
        <translation>Папка за съхранение на конвертираните данни не съществува.</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/ffmulticonverter.py" line="434"/>
        <source>Error!</source>
        <translation>Грешка!</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/ffmulticonverter.py" line="444"/>
        <source>Convert among several file types to other extensions</source>
        <translation type="obsolete">Конвертиране на файлове kъм други формати.</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/ffmulticonverter.py" line="254"/>
        <source>Missing dependencies:</source>
        <translation>Липсващи зависимости</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/ffmulticonverter.py" line="65"/>
        <source>Add</source>
        <translation>Добави</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/ffmulticonverter.py" line="66"/>
        <source>Delete</source>
        <translation>Изтрий</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/ffmulticonverter.py" line="147"/>
        <source>Clear All</source>
        <translation>Изчисти всички</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/ffmulticonverter.py" line="421"/>
        <source>You must add at least one file to convert!</source>
        <translation>Трябва да добавите поне един файл за да конвертирате!</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/ffmulticonverter.py" line="94"/>
        <source>Save each file in the same
folder as input file</source>
        <translation>Запазете всеки файл в същата папка
в която е запазен началният файл</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/ffmulticonverter.py" line="139"/>
        <source>Synchronize</source>
        <translation>Синхронизирай</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/ffmulticonverter.py" line="139"/>
        <source>Synchronize presets</source>
        <translation>Синхронизирай пресетите</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/ffmulticonverter.py" line="143"/>
        <source>Remove old</source>
        <translation>Премахни старите</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/ffmulticonverter.py" line="143"/>
        <source>Remove old presets</source>
        <translation>Премахни старите пресети</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/ffmulticonverter.py" line="170"/>
        <source>documentation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/ffmulticonverter.py" line="487"/>
        <source>Convert among several file types to other formats</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Preferences</name>
    <message>
        <location filename="../ffmulticonverter/preferences_dlg.py" line="43"/>
        <source>Save files</source>
        <translation>Запази файловете</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/preferences_dlg.py" line="44"/>
        <source>Existing files:</source>
        <translation>Съществуващи файлове:</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/preferences_dlg.py" line="45"/>
        <source>Add &apos;~&apos; prefix</source>
        <translation>Добави&apos;~&apos;префикс</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/preferences_dlg.py" line="46"/>
        <source>Overwrite</source>
        <translation>Запиши върху сегашният файл.</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/preferences_dlg.py" line="50"/>
        <source>Default output destination:</source>
        <translation>Папка по подразбиране за запазване на конвертираните файлове.</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/preferences_dlg.py" line="56"/>
        <source>Name files</source>
        <translation>Дай име на файловете</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/preferences_dlg.py" line="57"/>
        <source>Prefix:</source>
        <translation>Префикс</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/preferences_dlg.py" line="58"/>
        <source>Suffix:</source>
        <translation>Съфикс</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/preferences_dlg.py" line="73"/>
        <source>FFmpeg</source>
        <translation>FFmpeg</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/preferences_dlg.py" line="74"/>
        <source>Default command:</source>
        <translation>Команди по подразбиране</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/preferences_dlg.py" line="76"/>
        <source>Use:</source>
        <translation type="obsolete">Използвай:</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/preferences_dlg.py" line="78"/>
        <source>avconv</source>
        <translation type="obsolete">avconv</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/preferences_dlg.py" line="108"/>
        <source>General</source>
        <translation>Основни</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/preferences_dlg.py" line="109"/>
        <source>Audio/Video</source>
        <translation>Аудио/Видео</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/preferences_dlg.py" line="124"/>
        <source>Preferences</source>
        <translation>Предпочитания</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/preferences_dlg.py" line="177"/>
        <source>Choose default output destination</source>
        <translation>Изберете папка по подразбиране за резултатите от импортирането</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/preferences_dlg.py" line="77"/>
        <source>Video codecs</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/preferences_dlg.py" line="80"/>
        <source>Audio codecs</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/preferences_dlg.py" line="83"/>
        <source>Extra formats</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/preferences_dlg.py" line="91"/>
        <source>Default video codecs</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/preferences_dlg.py" line="92"/>
        <source>Default audio codecs</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Progress</name>
    <message>
        <location filename="../ffmulticonverter/progress.py" line="70"/>
        <source>In progress: </source>
        <translation>В прогрес</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/progress.py" line="71"/>
        <source>Total:</source>
        <translation>Общо</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/progress.py" line="76"/>
        <source>Cancel</source>
        <translation>Затвори</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/progress.py" line="78"/>
        <source>Details</source>
        <translation>Детайли</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/progress.py" line="111"/>
        <source>Conversion</source>
        <translation>Конвертиране</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/progress.py" line="172"/>
        <source>Converted: %1/%2</source>
        <translation type="obsolete">Конвертирани:%1/%2</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/progress.py" line="208"/>
        <source>Cancel Conversion</source>
        <translation>Прекрати конвертирането</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/progress.py" line="208"/>
        <source>Are you sure you want to cancel conversion?</source>
        <translation>Сигурни ли сте, че искате да прекратите конвертирането?</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/progress.py" line="244"/>
        <source>In progress:</source>
        <translation>В прогрес</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/progress.py" line="176"/>
        <source>Report</source>
        <translation>Доклад</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/progress.py" line="181"/>
        <source>Close</source>
        <translation>Затвори</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/progress.py" line="177"/>
        <source>Converted: {0}/{1}</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ShowPresets</name>
    <message>
        <location filename="../ffmulticonverter/presets_dlgs.py" line="43"/>
        <source>Preset label</source>
        <translation>Означение на пресет</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/presets_dlgs.py" line="46"/>
        <source>Preset command line parameters</source>
        <translation>Параметри на пресет.</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/presets_dlgs.py" line="49"/>
        <source>Output file extension</source>
        <translation>Екстенжън на конвертираният файл.</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/presets_dlgs.py" line="52"/>
        <source>Add</source>
        <translation>Добави</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/presets_dlgs.py" line="53"/>
        <source>Delete</source>
        <translation>Изтрии</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/presets_dlgs.py" line="54"/>
        <source>Delete all</source>
        <translation>Изтрий всички</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/presets_dlgs.py" line="55"/>
        <source>Edit</source>
        <translation>Промени</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/presets_dlgs.py" line="58"/>
        <source>OK</source>
        <translation>ОК</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/presets_dlgs.py" line="95"/>
        <source>Edit Presets</source>
        <translation>Промени пресет</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/presets_dlgs.py" line="288"/>
        <source>Delete Preset</source>
        <translation>Изтрий пресет</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/presets_dlgs.py" line="184"/>
        <source>Are you sure that you want to delete the %1 preset?</source>
        <translation type="obsolete">Сигурни ли сте, че искате да изтриете пресетът %1?</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/presets_dlgs.py" line="200"/>
        <source>Are you sure that you want to delete all presets?</source>
        <translation>Сигурни ли сте, че искате да изтриете всички пресети?</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/presets_dlgs.py" line="257"/>
        <source>All current presets will be deleted.
Are you sure that you want to continue?</source>
        <translation>Всички сегашни пресети ще бъдат изтрити.⏎
Сигурни ли сте, че искате да продължите?</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/presets_dlgs.py" line="288"/>
        <source>Are you sure that you want to restore the default presets?</source>
        <translation>Сигурни ли сте, че искате да възстановите зададените пресети по подразбиране.</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/presets_dlgs.py" line="257"/>
        <source>Succesful import!</source>
        <translation type="obsolete">Успешно импортиране!</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/presets_dlgs.py" line="267"/>
        <source>Import failed!</source>
        <translation>Импортирането неуспешно!</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/presets_dlgs.py" line="56"/>
        <source>Search</source>
        <translation>Търси</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/presets_dlgs.py" line="308"/>
        <source>Presets Synchronization</source>
        <translation>Синхронизация на пресетите</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/presets_dlgs.py" line="308"/>
        <source>Current presets and default presets will be merged. Are you sure that you want to continue?</source>
        <translation>Сегашните пресети и пресетите по подразбиране ще бъде съединени в едно. Сигурни ли сте, че искате да продължите?</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/presets_dlgs.py" line="357"/>
        <source>Remove old presets</source>
        <translation>Премахни старите пресети</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/presets_dlgs.py" line="341"/>
        <source>All presets with an __OLD prefix will be deleted. Are you sure that you want to continue?</source>
        <translation type="obsolete">Всички пресети завършващи на  __OLD ще бъдат изтрити. Сигурни ли сте, че искате да продължите?</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/presets_dlgs.py" line="186"/>
        <source>Are you sure that you want to delete the {0} preset?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/presets_dlgs.py" line="275"/>
        <source>Export presets</source>
        <translation type="unfinished">Експортирай пресетите</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/presets_dlgs.py" line="357"/>
        <source>All presets with an __OLD suffix will be deleted. Are you sure that you want to continue?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/presets_dlgs.py" line="263"/>
        <source>Successful import!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/presets_dlgs.py" line="295"/>
        <source>Default presets restored successfully.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/presets_dlgs.py" line="351"/>
        <source>Synchronization completed.
Your presets are up to date!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/presets_dlgs.py" line="372"/>
        <source>Old presets successfully removed.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Tab</name>
    <message>
        <location filename="../ffmulticonverter/audiovideotab.py" line="184"/>
        <source>More</source>
        <translation>Повече</translation>
    </message>
</context>
</TS>
